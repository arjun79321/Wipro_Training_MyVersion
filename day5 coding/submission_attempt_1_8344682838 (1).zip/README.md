# Sample React

### Stack
    node_react

### Type
    frontend

### To Run Test cases
    npm test
    
### To Start the server 
    npm start

### Score File
    /home/workspace/app/gl_mock/gl_sample_react/junit.xml
